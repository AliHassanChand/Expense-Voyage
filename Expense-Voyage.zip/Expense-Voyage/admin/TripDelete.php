<?php
include("config.php");
$id = $_GET['id'];
$sql = "DELETE FROM service_detail WHERE id = {$id}";
$result = mysqli_query($con, $sql);
if ($result == true) {
	$msg = "<p class='alert alert-success'>Categories Deleted</p>";
	header("Location:Tripadd.php?msg=$msg");
} else {
	$msg = "<p class='alert alert-warning'>Categories Not Deleted</p>";
	header("Location:Tripadd.php?msg=$msg");
}
mysqli_close($con);

<?php
session_start();
include("config.php");

if (!isset($_SESSION['auser'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $team_id = $_GET['id'];

    // Fetch team member details
    $query = "SELECT * FROM team WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 'i', $team_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $team_member = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $full_name = $_POST['full_name'];
            $designation = $_POST['designation'];
            $image_url = $_POST['image_url'];
            $facebook_url = $_POST['facebook_url'];
            $twitter_url = $_POST['twitter_url'];
            $instagram_url = $_POST['instagram_url'];

            // Prepare the update query
            $update_query = "UPDATE team SET full_name=?, designation=?, image_url=?, facebook_url=?, twitter_url=?, instagram_url=? WHERE id=?";

            // Prepare the statement
            if ($stmt = mysqli_prepare($con, $update_query)) {
                $params = [$full_name, $designation, $image_url, $facebook_url, $twitter_url, $instagram_url, $team_id];
                mysqli_stmt_bind_param($stmt, 'ssssssi', ...$params); // 's' for string, 'i' for integer

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: team.php?msg=Team member details updated successfully");
                    exit();
                } else {
                    echo "Error: " . mysqli_error($con);
                }
            } else {
                die("Statement preparation failed: " . mysqli_error($con));
            }
        }
    } else {
        header("Location: adminlist.php");
        exit();
    }
} else {
    header("Location: adminlist.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Expense Voyage - Admin-Edit</title>
</head>
<?php include 'head.php'; ?>

<body>
    <?php include("header.php"); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="container">
                <h2>Edit Admin</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($team_member['full_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="designation">Designation</label>
                        <input type="text" class="form-control" id="designation" name="designation" value="<?php echo htmlspecialchars($team_member['designation']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="image_url">Image URL</label>
                        <input type="text" class="form-control" id="image_url" name="image_url" value="<?php echo htmlspecialchars($team_member['image_url']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="facebook_url">Facebook URL</label>
                        <input type="text" class="form-control" id="facebook_url" name="facebook_url" value="<?php echo htmlspecialchars($team_member['facebook_url']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="twitter_url">Twitter URL</label>
                        <input type="text" class="form-control" id="twitter_url" name="twitter_url" value="<?php echo htmlspecialchars($team_member['twitter_url']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="instagram_url">Instagram URL</label>
                        <input type="text" class="form-control" id="instagram_url" name="instagram_url" value="<?php echo htmlspecialchars($team_member['instagram_url']); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>
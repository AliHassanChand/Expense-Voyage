<?php
include("config.php");
$aid = $_GET['id'];
$sql = "DELETE FROM team WHERE id = {$aid}";
$result = mysqli_query($con, $sql);
if ($result == true) {
	$msg = "<p class='alert alert-success'>Admin Deleted</p>";
	header("Location:team.php?msg=$msg");
} else {
	$msg = "<p class='alert alert-warning'>Admin Not Deleted</p>";
	header("Location:team.php?msg=$msg");
}
mysqli_close($con);

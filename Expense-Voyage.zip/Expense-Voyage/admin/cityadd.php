<?php
session_start();
include("config.php");

if (!isset($_SESSION['auser'])) {
	header("location:index.php");
}

$error = "";
$msg = "";

if (isset($_POST['insert'])) {
	$country_name = $_POST['country_name'];
	$country_img = $_POST['country_img']; // Assuming the image URL or path is posted

	if (!empty($country_name) && !empty($country_img)) {
		$sql = "INSERT INTO countries (country_name, country_image) VALUES ('$country_name', '$country_img')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$msg = "<p class='alert alert-success'>Country Inserted Successfully</p>";
		} else {
			$error = "<p class='alert alert-warning'>* Country Not Inserted</p>";
		}
	} else {
		$error = "<p class='alert alert-warning'>* Fill all the Fields</p>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Expense Voyage - All Countries</title>
</head>
<?php include 'head.php'; ?>

<body>

	<!-- Main Wrapper -->


	<!-- Header -->
	<?php include("header.php"); ?>
	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col">
						<h3 class="page-title">State</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
							<li class="breadcrumb-item active">State</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<!-- city add section -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h1 class="card-title">Add Destination</h1>
							<?php echo $error; ?>
							<?php echo $msg; ?>
							<?php
							if (isset($_GET['msg']))
								echo $_GET['msg'];
							?>
						</div>
						<form method="post" id="insert product" enctype="multipart/form-data">
							<div class="card-body">
								<div class="row">
									<div class="col-xl-6">
										<h5 class="card-title">Country Details</h5>
										<div class="form-group row">
											<label class="col-lg-3 col-form-label">Country Name</label>
											<div class="col-lg-9">
												<input type="text" class="form-control" name="country_name" required>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-lg-3 col-form-label">Country Image URL</label>
											<div class="col-lg-9">
												<input type="text" class="form-control" name="country_img" required>
											</div>
										</div>
									</div>
								</div>
								<div class="text-left">
									<input type="submit" class="btn btn-primary" value="Submit" name="insert" style="margin-left:200px;">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<!----End City add section  --->

			<!----view city  --->
			<div class="row">
				<div class="col-sm-12">
					<div class="card">
						<div class="card-header">
							<h4 class="card-title">City List</h4>

						</div>
						<div class="card-body">

							<table id="basic-datatable" class="table table-bordered table-hover">
								<thead>
									<tr>
										<th>#</th>
										<th>Country Name</th>
										<th>Country Image</th>
										<th>Actions</th>
									</tr>
								</thead>

								<tbody>
									<?php
									$query = mysqli_query($con, "SELECT * FROM countries");
									$cnt = 1;
									while ($row = mysqli_fetch_array($query)) {
									?>
										<tr>
											<td><?php echo $cnt; ?></td>
											<td><?php echo $row['country_name']; ?></td>
											<td><img src="<?php echo $row['country_image']; ?>" alt="<?php echo $row['country_name']; ?>" width="50"></td>
											<td>
												<a href="countryedit.php?id=<?php echo $row['id']; ?>"><button class="btn btn-info">Edit</button></a>
												<a href="countrydelete.php?id=<?php echo $row['id']; ?>"><button class="btn btn-danger">Delete</button></a>
											</td>
										</tr>
									<?php $cnt++;
									} ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>
			</div>
			<!-- view City -->
		</div>
	</div>
	<!-- /Main Wrapper -->
	<!---
			
			
			
			---->

	<!-- jQuery -->
	<script src="assets/js/jquery-3.2.1.min.js"></script>

	<!-- Bootstrap Core JS -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Slimscroll JS -->
	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

	<!-- Datatables JS -->
	<!-- Datatables JS -->
	<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
	<script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
	<script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

	<script src="assets/plugins/datatables/dataTables.select.min.js"></script>

	<script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
	<script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
	<script src="assets/plugins/datatables/buttons.html5.min.js"></script>
	<script src="assets/plugins/datatables/buttons.flash.min.js"></script>
	<script src="assets/plugins/datatables/buttons.print.min.js"></script>

	<!-- Custom JS -->
	<script src="assets/js/script.js"></script>

</body>

</html>
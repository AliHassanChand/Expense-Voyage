<?php
session_start();
require("config.php");

if (!isset($_SESSION['auser'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Expense Voyage - All Team </title>
</head>
<?php include 'head.php'; ?>

<body>
    <!-- Main Wrapper -->
    <!-- Header -->
    <?php include("header.php"); ?>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content container-fluid">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title">Admin</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Admin</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Guide List</h4>
                            <?php
                            if (isset($_GET['msg'])) {
                                echo htmlspecialchars($_GET['msg']);
                            }
                            ?>
                        </div>
                        <div class="card-body">
                            <!-- Make table responsive for smaller devices -->
                            <div class="table-responsive">
                                <table id="basic-datatable" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Full Name</th>
                                            <th>Designation</th>
                                            <th>Facebook</th>
                                            <th>Twitter</th>
                                            <th>Instagram</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = mysqli_query($con, "SELECT * FROM team");
                                        $cnt = 1;

                                        while ($row = mysqli_fetch_assoc($query)) {
                                        ?>
                                            <tr>
                                                <td><?php echo $cnt; ?></td>
                                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['designation']); ?></td>
                                                <td><?php echo htmlspecialchars($row['facebook_url']); ?></td>
                                                <td><?php echo htmlspecialchars($row['twitter_url']); ?></td>
                                                <td><?php echo htmlspecialchars($row['instagram_url']); ?></td>
                                                <td>
                                                    <div class="d-grid gap-2 d-md-block">
                                                        <a href="teamedit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm mb-2">Edit</a>
                                                        <a href="teamdelete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm mb-2">Delete</a>
                                                    </div>
                                                </td>
                                            </tr>

                                        <?php
                                            $cnt++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Main Wrapper -->
    <!-- jQuery -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap Core JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Additional JS -->
    <script src="assets/js/script.js"></script>
</body>

</html>
<?php
session_start();

// Include database configuration
include('config.php');

if (!isset($_SESSION['auser'])) {
    header("location:index.php");
    exit();
}

$error = "";
$msg = "";

// Fetch categories for dropdown (if needed)
$categories_query = mysqli_query($con, "SELECT id, category_name FROM categories"); // Adjust the query as per your requirements

if (isset($_POST['insert'])) {
    $category_id = $_POST['category_id'];
    $service_name = $_POST['service_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $destination = $_POST['destination'];
    $facilities = $_POST['facilities'];
    $available_class_type = $_POST['available_class_type'];
    $trip_type = $_POST['trip_type'];
    $img1 = $_POST['img1'];
    $img2 = $_POST['img2'];
    $img3 = $_POST['img3'];
    $img4 = $_POST['img4'];

    // Validate required fields
    if (!empty($category_id) && !empty($service_name) && !empty($price) && !empty($duration) && !empty($destination)) {
        $sql = "INSERT INTO service_detail (category_id, service_name, description, price, duration, destination, facilities, available_class_type, trip_type, img1, img2, img3, img4) 
        VALUES ('$category_id', '$service_name', '$description', '$price', '$duration', '$destination', '$facilities', '$available_class_type', '$trip_type', '$img1', '$img2', '$img3', '$img4')";

        $result = mysqli_query($con, $sql);
        if ($result) {
            $msg = "<p class='alert alert-success'>Service Inserted Successfully</p>";
        } else {
            $error = "<p class='alert alert-warning'>* Service Not Inserted</p>";
        }
    } else {
        $error = "<p class='alert alert-warning'>* Fill all the Required Fields</p>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">


<head>
    <title>Expense Voyage - All Trips</title>
</head>

<?php include 'head.php'; ?>

<body>

    <!-- Main Wrapper -->


    <!-- Header -->
    <?php include("header.php"); ?>
    <!-- /Sidebar -->

    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title">All Trips</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">All Trips</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <!-- city add section -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h1 class="card-title">Add Service</h1>
                            <?php echo $error; ?>
                            <?php echo $msg; ?>
                            <?php if (isset($_GET['msg'])) echo $_GET['msg']; ?>
                        </div>
                        <form method="post" id="insert_service">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-6">
                                        <h5 class="card-title">Service Details</h5>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Category</label>
                                            <div class="col-lg-9">
                                                <select class="form-control" name="category_id" required>
                                                    <option value="">Select Category</option>
                                                    <?php while ($row = mysqli_fetch_assoc($categories_query)) { ?>
                                                        <option value="<?php echo htmlspecialchars($row['id']); ?>">
                                                            <?php echo htmlspecialchars($row['category_name']); ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Service Name</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="service_name" required placeholder="Enter Service Name">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Description</label>
                                            <div class="col-lg-9">
                                                <textarea class="form-control" name="description" rows="5" required placeholder="Enter Description"></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Price</label>
                                            <div class="col-lg-9">
                                                <input type="number" class="form-control" name="price" step="0.01" required placeholder="Enter Price">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Duration</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="duration" required placeholder="Enter Duration">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Destination</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="destination" required placeholder="Enter Destination">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Facilities (optional)</label>
                                            <div class="col-lg-9">
                                                <textarea class="form-control" name="facilities" rows="5" placeholder="Enter Facilities"></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Available Class Type</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="available_class_type" required placeholder="Enter Available Class Type">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Trip Type</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="trip_type" required placeholder="Enter Trip Type">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Image 1 URL</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="img1" placeholder="Enter Image 1 URL">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Image 2 URL</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="img2" placeholder="Enter Image 2 URL">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Image 3 URL</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="img3" placeholder="Enter Image 3 URL">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label">Image 4 URL</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control" name="img4" placeholder="Enter Image 4 URL">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="text-left">
                                    <input type="submit" class="btn btn-primary" value="Submit" name="insert" style="margin-left:200px;">
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <!----End City add section  --->

            <!----view trips  --->
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Trip List</h4>
                        </div>
                        <div class="card-body">

                            <table id="basic-datatable" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Service Name</th>
                                        <th>Description</th>
                                        <th>Price</th>
                                        <th>Duration</th>
                                        <th>Destination</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = mysqli_query($con, "SELECT sd.id, sd.service_name, sd.description, sd.price, sd.duration, sd.destination FROM service_detail sd");
                                    $cnt = 1;
                                    while ($row = mysqli_fetch_array($query)) {
                                    ?>
                                        <tr>
                                            <td><?php echo $cnt; ?></td>
                                            <td><?php echo htmlspecialchars($row['service_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                                            <td><?php echo htmlspecialchars($row['price']); ?></td>
                                            <td><?php echo htmlspecialchars($row['duration']); ?></td>
                                            <td><?php echo htmlspecialchars($row['destination']); ?></td>
                                            <td>
                                                <a href="TripEdit.php?id=<?php echo $row['id']; ?>"><button class="btn btn-info">Edit</button></a>
                                                <a href="TripDelete.php?id=<?php echo $row['id']; ?>"><button class="btn btn-danger">Delete</button></a>
                                            </td>
                                        </tr>
                                    <?php $cnt++;
                                    } ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
            <!-- view Trips -->

        </div>
    </div>
    <!-- /Main Wrapper -->
    <!---
			
			
			
			---->

    <!-- jQuery -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>

    <!-- Bootstrap Core JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Slimscroll JS -->
    <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Datatables JS -->
    <!-- Datatables JS -->
    <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
    <script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

    <script src="assets/plugins/datatables/dataTables.select.min.js"></script>

    <script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
    <script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
    <script src="assets/plugins/datatables/buttons.html5.min.js"></script>
    <script src="assets/plugins/datatables/buttons.flash.min.js"></script>
    <script src="assets/plugins/datatables/buttons.print.min.js"></script>

    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>

</body>

</html>
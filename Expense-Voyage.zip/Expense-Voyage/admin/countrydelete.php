<?php
include("config.php");
$id = $_GET['id'];
$sql = "DELETE FROM countries WHERE id = {$id}";
$result = mysqli_query($con, $sql);
if ($result == true) {
	$msg = "<p class='alert alert-success'>Country Deleted</p>";
	header("Location:cityadd.php?msg=$msg");
} else {
	$msg = "<p class='alert alert-warning'>Country Not Deleted</p>";
	header("Location:cityadd.php?msg=$msg");
}
mysqli_close($con);

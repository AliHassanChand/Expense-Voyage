<?php
session_start();
include("config.php");
if (!isset($_SESSION['auser'])) {
	header("location:index.php");
}

// Initialize messages
$error = "";
$msg = "";

// Check if the form is submitted
if (isset($_POST['insert'])) {
	$cid = $_GET['id']; // Get category ID from URL
	$country_id = $_POST['country_id']; // Assuming country_id is sent from a dropdown
	$category_name = $_POST['category_name'];
	$description = $_POST['description'];
	$icon = $_POST['icon']; // Icon as text input

	if (!empty($country_id) && !empty($category_name) && !empty($description) && !empty($icon)) {
		$sql = "UPDATE categories SET country_id = '{$country_id}', category_name = '{$category_name}', description = '{$description}', icon = '{$icon}' WHERE id = {$cid}";
		$result = mysqli_query($con, $sql);

		if ($result) {
			$msg = "<p class='alert alert-success'>Category Updated</p>";
			header("Location: categories.php?msg=$msg");
			exit();
		} else {
			$msg = "<p class='alert alert-warning'>Category Not Updated</p>";
			header("Location: categories.php?msg=$msg");
			exit();
		}
	} else {
		$error = "<p class='alert alert-warning'>* Please Fill all the Fields</p>";
	}
}

// Fetch category details
$cid = $_GET['id'];
$sql = "SELECT * FROM categories WHERE id = {$cid}";
$result = mysqli_query($con, $sql);

// Check for errors
if (!$result) {
	die("Query failed: " . mysqli_error($con));
}

// Check if any category was found
if (mysqli_num_rows($result) == 0) {
	echo "<p class='alert alert-warning'>No category found with this ID.</p>";
	exit();
}
?>
<!DOCTYPE html>
<html lang="en">


<head>
	<title>Expense Voyage - Countries Edit</title>
</head>
<?php include 'head.php'; ?>

<body>

	<!-- Main Wrapper -->


	<!-- Header -->
	<?php include("header.php"); ?>
	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col">
						<h3 class="page-title">State</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
							<li class="breadcrumb-item active">State</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<!-- city add section -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h1 class="card-title">Add City</h1>
							<?php
							// Start output
							while ($row = mysqli_fetch_assoc($result)) {
							?>

								<div>
									<?php echo $error; ?>
									<?php echo $msg; ?>
									<?php if (isset($_GET['msg'])) echo $_GET['msg']; ?>
								</div>

								<form method="post">
									<div class="card-body">
										<div class="row">
											<div class="col-xl-6">
												<h5 class="card-title">Category Details</h5>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Country</label>
													<div class="col-lg-9">
														<select class="form-control" name="country_id" required>
															<option value="">Select Country</option>
															<?php
															// Fetch countries for dropdown
															$countries_query = mysqli_query($con, "SELECT id, country_name FROM countries");
															while ($country = mysqli_fetch_assoc($countries_query)) {
																$selected = ($country['id'] == $row['country_id']) ? 'selected' : '';
																echo "<option value='{$country['id']}' {$selected}>" . htmlspecialchars($country['country_name']) . "</option>";
															}
															?>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Category Name</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="category_name" value="<?php echo htmlspecialchars($row['category_name']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Description</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="description" rows="5" required><?php echo htmlspecialchars($row['description']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Icon</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="icon" value="<?php echo htmlspecialchars($row['icon']); ?>" required>
													</div>
												</div>
											</div>
										</div>
										<div class="text-left">
											<input type="submit" class="btn btn-primary" value="Submit" name="insert" style="margin-left:200px;">
										</div>
									</div>
								</form>

							<?php
							}
							?>
						</div>
					</div>
				</div>
				<!----End City add section  --->

			</div>
		</div>
		<!-- /Main Wrapper -->
		<!---
			
			
			
			---->

		<!-- jQuery -->
		<script src="assets/js/jquery-3.2.1.min.js"></script>

		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

		<!-- Datatables JS -->
		<!-- Datatables JS -->
		<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

		<script src="assets/plugins/datatables/dataTables.select.min.js"></script>

		<script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatables/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatables/buttons.flash.min.js"></script>
		<script src="assets/plugins/datatables/buttons.print.min.js"></script>

		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>

</body>

</html>
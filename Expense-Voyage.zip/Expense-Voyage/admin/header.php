<div class="header">

    <!-- Logo -->
    <div class="header-left">
        <a href="dashboard.php" class="logo">
            <img src="assets/img/logo-1.png" alt="">
            <span style="font-size: 24px; font-weight: bold;">Expense Voyoga </span>
        </a>
    </div>

    <!-- /Logo -->

    <a href="javascript:void(0);" id="toggle_btn">
        <i class="fe fe-text-align-left"></i>
    </a>



    <!-- Mobile Menu Toggle -->
    <a class="mobile_btn" id="mobile_btn">
        <i class="fa fa-bars"></i>
    </a>
    <!-- /Mobile Menu Toggle -->

    <!-- Header Right Menu -->
    <ul class="nav user-menu">


        <!-- User Menu -->
        <!-- <h4 style="color:white;margin-top:13px;text-transform:capitalize;"><?php echo $_SESSION['auser']; ?></h4> -->
        <li class="nav-item dropdown app-dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <h2> Welcome : <?php echo $_SESSION['auser']; ?></h2>
            </a>

            <div class="dropdown-menu">
                <div class="user-header">

                    <div class="user-text">
                        <h6><?php echo $_SESSION['auser']; ?></h6>
                        <p class="text-muted mb-0">Administrator</p>
                    </div>
                </div>
                <a class="dropdown-item" href="profile.php">Profile</a>
                <a class="dropdown-item" href="logout.php">Logout</a>
            </div>
        </li>

        <!-- /User Menu -->

    </ul>
    <!-- /Header Right Menu -->

</div>

<!-- header --->



<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">
                    <span>Main</span>
                </li>
                <li>
                    <a href="dashboard.php"><i class="fe fe-home"></i> <span>Dashboard</span></a>
                </li>

                <li class="menu-title">
                    <span>All Users</span>
                </li>

                <li class="submenu">
                    <a href="#"><i class="fe fe-user"></i> <span> All Users </span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="adminlist.php"> Admin </a></li>
                        <li><a href="userlist.php"> Users </a></li>
                        <li><a href="team.php"> Guide </a></li>
                    </ul>
                </li>

                <li class="menu-title">
                    <span>Destination</span>
                </li>

                <li class="submenu">
                    <a href="#"><i class="fe fe-location"></i> <span> Country </span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="cityadd.php"> Country </a></li>

                    </ul>
                </li>

                <li class="submenu">
                    <a href="#"><i class="fe fe-book"></i> <span> Services </span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="categories.php"> Categories </a></li>

                    </ul>
                </li>

                <li class="menu-title">
                    <span>Trip Management</span>
                </li>

                <li class="submenu">
                    <a href="#"><i class="fa fa-globe"></i> <span> Combine Trips </span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                    <li><a href="Tripadd.php"> Trips </a></li>
                        <li><a href="combineTrips.php"> Combine Trips </a></li>

                    </ul>
                </li>

                <li class="menu-title">
                    <span>Query</span>
                </li>
                <li class="submenu">
                    <a href="#"><i class="fe fe-comment"></i> <span> Contact</span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="contactview.php"> Contact </a></li>
                    </ul>
                </li>
                

            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
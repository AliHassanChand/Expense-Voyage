<?php
session_start();
include("config.php");

$error = "";
$msg = ""; // Initialize msg

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

    if (!empty($username) && !empty($email) && !empty($password)) {
        // Check if the username or email already exists
        $query = "SELECT * FROM admins WHERE username = ? OR email = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, 'ss', $username, $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 0) {
            // Insert the new admin
            $insert_query = "INSERT INTO admins (username, password, email) VALUES (?, ?, ?)";
            $insert_stmt = mysqli_prepare($con, $insert_query);
            mysqli_stmt_bind_param($insert_stmt, 'sss', $username, $password, $email);
            mysqli_stmt_execute($insert_stmt);

            if (mysqli_stmt_affected_rows($insert_stmt) > 0) {
                $msg = "<p class='alert alert-success'>Registration successful!</p>";
                // Optionally, redirect to another page (uncomment if needed)
                header("Location: login.php"); 
                exit();
            } else {
                $error = "<p class='alert alert-warning'>Registration failed!</p>";
            }
        } else {
            $error = "<p class='alert alert-warning'>Username or Email already exists!</p>";
        }
    } else {
        $error = "* Please fill in all fields!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>Tameer.com</title>
    <title>RE Admin - Login</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <div class="page-wrapper login-body">
        <div class="login-wrapper">
            <div class="container">
                <div class="loginbox" style="margin-left: 250px !important;">
                    <div class="login-right">
                        <div class="login-right-wrap">
                            <h1>Admin Registration</h1>
                            <p class="account-subtitle">Access to our admin dashboard</p>
                            <div style="color:green;"><?php echo $msg; ?></div>
                            <div style="color:red;"><?php echo $error; ?></div>
                            <!-- Form -->
                            <form method="post">
                                <div class="form-group">
                                    <input class="form-control" name="username" type="text" placeholder="User Name" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="email" name="email" placeholder="Enter Your Email" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="password" name="password" placeholder="Enter Your Password" required>
                                </div>
                                <hr>
                                <p>already have an account <a href="login.php">Login Now</a></p>
                                <div class="form-group">
                                    <button class="btn btn-primary btn-block" name="register" type="submit">Register</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap Core JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
</body>

</html>
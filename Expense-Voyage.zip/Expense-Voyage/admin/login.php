<?php
session_start();
include("config.php");
$error = "";

if (isset($_POST['login'])) {
    $username = $_POST['user']; // Assuming the input name is still 'user'
    $password = $_POST['pass']; // Assuming the input name is still 'pass'

    if (!empty($username) && !empty($password)) {
        // Fetch the user data based on the username
        $query = "SELECT username, password FROM admins WHERE username = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            $stored_pass = $row['password'];

            // Verify the password
            if (password_verify($password, $stored_pass)) {
                $_SESSION['auser'] = $username; // Store the username in session
                header("Location: dashboard.php");
                exit();
            } else {
                $error = '* Invalid username or password';
            }
        } else {
            $error = '* Invalid username or password';
        }
    } else {
        $error = "* Please fill in all fields!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Expense Voyage - Admin-Login</title>
</head>
<?php include 'head.php'; ?>

<body>

    <div class="login-body">
        <div class="login-wrapper">
            <div class="container">
                <div class="loginbox" style="margin-left: 300px !important;">
                    <div class="login-right">
                        <div class="login-right-wrap">
                            <h1>Admin Login Panel</h1>
                            <p class="account-subtitle">Access to our dashboard</p>
                            <p style="color:red;"><?php echo $error; ?></p>
                            <!-- Form -->
                            <form action="login.php" method="post">
                                <div class="form-group">
                                    <input class="form-control" name="user" type="text" placeholder="User Name" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="password" name="pass" placeholder="Password" required>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary btn-block" name="login" type="submit">Login</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap Core JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
</body>

</html>
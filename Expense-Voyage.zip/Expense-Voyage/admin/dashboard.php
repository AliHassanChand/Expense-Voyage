<?php
session_start();
require("config.php");
////code

if (!isset($_SESSION['auser'])) {
	header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>Expense Voyage - Admin-Dashboard</title>
</head>
<?php
include 'head.php';
?>

<body>

	<!-- Main Wrapper -->


	<!-- Header -->
	<?php include("header.php"); ?>
	<!-- /Header -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">

		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col-sm-12">
						<h3 class="page-title" style="font-weight: bold;text-transform: uppercase; font-size: 5vh;">Admin Dashboard</h3>

					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<div class="row">
				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-primary">
									<i class="fe fe-users"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM users WHERE is_verified = '0'";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Registered Users</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-primary w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-success">
									<i class="fe fe-globe"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM countries";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Countries</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-success w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-danger">
									<i class="fe fe-book"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM categories";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Services</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-danger w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-info">
									<i class="fe fe-building"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM service_detail where category_id = '1'";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Hotels</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-info w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


			<div class="row">
				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-warning">
									<i class="fa fa-plane"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM service_detail where category_id = '2'";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Flights</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-info w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-danger">
									<i class="fa fa-car"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM service_detail where category_id = '3'";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Car Rentals</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-info w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-info">
									<i class="fe fe-user"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM team";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Our Guides</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-info w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-xl-3 col-sm-6 col-12">
					<div class="card">
						<div class="card-body">
							<div class="dash-widget-header">
								<span class="dash-widget-icon bg-secondary">
									<i class="fa fa-id-badge"></i>
								</span>

							</div>
							<div class="dash-widget-info">

								<h3><?php $sql = "SELECT * FROM bookings";
									$query = $con->query($sql);
									echo "$query->num_rows"; ?></h3>

								<h6 class="text-muted">Bookings</h6>
								<div class="progress progress-sm">
									<div class="progress-bar bg-info w-50"></div>
								</div>
							</div>
						</div>
					</div>
				</div>


			</div>
		</div>
	</div>
	<!-- /Page Wrapper -->


	<!-- /Main Wrapper -->

	<!-- jQuery -->
	<script src="assets/js/jquery-3.2.1.min.js"></script>

	<!-- Bootstrap Core JS -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Slimscroll JS -->
	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

	<script src="assets/plugins/raphael/raphael.min.js"></script>
	<script src="assets/plugins/morris/morris.min.js"></script>
	<script src="assets/js/chart.morris.js"></script>

	<!-- Custom JS -->
	<script src="assets/js/script.js"></script>

</body>

</html>
<?php
session_start();
include("config.php");

if (!isset($_SESSION['auser'])) {
	header("location:index.php");
}

// Initialize messages
$error = "";
$msg = "";

// Check if the form is submitted
if (isset($_POST['insert'])) {
	$sid = $_GET['id']; // Get service ID from URL
	$category_id = $_POST['category_id']; // Assuming category_id is sent from a dropdown
	$service_name = $_POST['service_name'];
	$description = $_POST['description'];
	$price = $_POST['price'];
	$duration = $_POST['duration'];
	$destination = $_POST['destination'];
	$facilities = $_POST['facilities'];
	$available_class_type = $_POST['available_class_type'];
	$trip_type = $_POST['trip_type'];
	$img1 = $_POST['img1'];
	$img2 = $_POST['img2'];
	$img3 = $_POST['img3'];
	$img4 = $_POST['img4'];

	if (!empty($category_id) && !empty($service_name) && !empty($price) && !empty($duration) && !empty($destination)) {
		$sql = "UPDATE service_detail SET category_id = '{$category_id}', service_name = '{$service_name}', description = '{$description}', price = '{$price}', duration = '{$duration}', destination = '{$destination}', facilities = '{$facilities}', available_class_type = '{$available_class_type}', trip_type = '{$trip_type}', img1 = '{$img1}', img2 = '{$img2}', img3 = '{$img3}', img4 = '{$img4}' WHERE id = {$sid}";

		$result = mysqli_query($con, $sql);

		if ($result) {
			$msg = "<p class='alert alert-success'>Service Updated Successfully</p>";
			header("Location: Tripadd.php?msg=$msg");
			exit();
		} else {
			$msg = "<p class='alert alert-warning'>Service Not Updated</p>";
			header("Location: Tripadd.php?msg=$msg");
			exit();
		}
	} else {
		$error = "<p class='alert alert-warning'>* Please Fill all the Fields</p>";
	}
}

// Fetch service details
$sid = $_GET['id'];
$sql = "SELECT * FROM service_detail WHERE id = {$sid}";
$result = mysqli_query($con, $sql);

// Check for errors
if (!$result) {
	die("Query failed: " . mysqli_error($con));
}

// Check if any service was found
if (mysqli_num_rows($result) == 0) {
	echo "<p class='alert alert-warning'>No service found with this ID.</p>";
	exit();
}
?>

<!DOCTYPE html>
<html lang="en">


<head>
	<title>Expense Voyage - Trip Edit</title>
</head>
<?php include 'head.php'; ?>

<body>

	<!-- Main Wrapper -->


	<!-- Header -->
	<?php include("header.php"); ?>
	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col">
						<h3 class="page-title">State</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
							<li class="breadcrumb-item active">State</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<!-- city add section -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h1 class="card-title">Add City</h1>
							<?php
							// Start output
							while ($row = mysqli_fetch_assoc($result)) {
							?>

								<div>
									<?php echo $error; ?>
									<?php echo $msg; ?>
									<?php if (isset($_GET['msg'])) echo $_GET['msg']; ?>
								</div>

								<form method="post">
									<div class="card-body">
										<div class="row">
											<div class="col-xl-6">
												<h5 class="card-title">Service Details</h5>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Category</label>
													<div class="col-lg-9">
														<select class="form-control" name="category_id" required>
															<option value="">Select Category</option>
															<?php
															// Fetch categories for dropdown
															$categories_query = mysqli_query($con, "SELECT id, category_name FROM categories");
															while ($category = mysqli_fetch_assoc($categories_query)) {
																$selected = ($category['id'] == $row['category_id']) ? 'selected' : '';
																echo "<option value='{$category['id']}' {$selected}>" . htmlspecialchars($category['category_name']) . "</option>";
															}
															?>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Service Name</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="service_name" value="<?php echo htmlspecialchars($row['service_name']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Description</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="description" rows="5" required><?php echo htmlspecialchars($row['description']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Price</label>
													<div class="col-lg-9">
														<input type="number" class="form-control" name="price" step="0.01" value="<?php echo htmlspecialchars($row['price']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Duration</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="duration" value="<?php echo htmlspecialchars($row['duration']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Destination</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="destination" value="<?php echo htmlspecialchars($row['destination']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Facilities (optional)</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="facilities" rows="5" placeholder="Enter Facilities"><?php echo htmlspecialchars($row['facilities']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Available Class Type</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="available_class_type" value="<?php echo htmlspecialchars($row['available_class_type']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Trip Type</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="trip_type" value="<?php echo htmlspecialchars($row['trip_type']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 1 URL</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="img1" value="<?php echo htmlspecialchars($row['img1']); ?>" placeholder="Enter Image 1 URL">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 2 URL</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="img2" value="<?php echo htmlspecialchars($row['img2']); ?>" placeholder="Enter Image 2 URL">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 3 URL</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="img3" value="<?php echo htmlspecialchars($row['img3']); ?>" placeholder="Enter Image 3 URL">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 4 URL</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="img4" value="<?php echo htmlspecialchars($row['img4']); ?>" placeholder="Enter Image 4 URL">
													</div>
												</div>
											</div>
										</div>
										<div class="text-left">
											<input type="submit" class="btn btn-primary" value="Submit" name="insert" style="margin-left:200px;">
										</div>
									</div>
								</form>

							<?php
							}
							?>
						</div>
					</div>
				</div>
				<!----End City add section  --->

			</div>
		</div>
		<!-- /Main Wrapper -->
		<!---
			
			
			
			---->

		<!-- jQuery -->
		<script src="assets/js/jquery-3.2.1.min.js"></script>

		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

		<!-- Datatables JS -->
		<!-- Datatables JS -->
		<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

		<script src="assets/plugins/datatables/dataTables.select.min.js"></script>

		<script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatables/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatables/buttons.flash.min.js"></script>
		<script src="assets/plugins/datatables/buttons.print.min.js"></script>

		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>

</body>

</html>
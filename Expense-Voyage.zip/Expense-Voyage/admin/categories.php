<?php
session_start();

// Include database configuration
include('config.php');

if (!isset($_SESSION['auser'])) {
	header("location:index.php");
	exit();
}

$error = "";
$msg = "";

// Fetch countries for dropdown
$countries_query = mysqli_query($con, "SELECT id, country_name FROM countries");

if (isset($_POST['insert'])) {
	$country_id = $_POST['country_id'];
	$category_name = $_POST['category_name'];
	$description = $_POST['description'];
	$icon = $_POST['icon']; // Assuming the icon URL is posted

	if (!empty($country_id) && !empty($category_name) && !empty($description) && !empty($icon)) {
		$sql = "INSERT INTO categories (country_id, category_name, description, icon) VALUES ('$country_id', '$category_name', '$description', '$icon')";
		$result = mysqli_query($con, $sql);
		if ($result) {
			$msg = "<p class='alert alert-success'>Category Inserted Successfully</p>";
		} else {
			$error = "<p class='alert alert-warning'>* Category Not Inserted</p>";
		}
	} else {
		$error = "<p class='alert alert-warning'>* Fill all the Fields</p>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">


<head>
	<title>Expense Voyage - All Categories</title>
</head>
<?php include 'head.php'; ?>

<body>

	<!-- Main Wrapper -->


	<!-- Header -->
	<?php include("header.php"); ?>
	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col">
						<h3 class="page-title">State</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
							<li class="breadcrumb-item active">State</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<!-- city add section -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h1 class="card-title">Add Destination</h1>
							<?php echo $error; ?>
							<?php echo $msg; ?>
							<?php if (isset($_GET['msg'])) echo $_GET['msg']; ?>
						</div>
						<form method="post" id="insert product">
							<div class="card-body">
								<div class="row">
									<div class="col-xl-6">
										<h5 class="card-title">Category Details</h5>
										<div class="form-group row">
											<label class="col-lg-3 col-form-label">Country</label>
											<div class="col-lg-9">
												<select class="form-control" name="country_id" required>
													<option value="">Select Country</option>
													<?php while ($row = mysqli_fetch_assoc($countries_query)) { ?>
														<option value="<?php echo $row['id']; ?>">
															<?php echo htmlspecialchars($row['country_name']); ?>
														</option>
													<?php } ?>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-lg-3 col-form-label">Category Name</label>
											<div class="col-lg-9">
												<input type="text" class="form-control" name="category_name" required>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-lg-3 col-form-label">Description</label>
											<div class="col-lg-9">
												<textarea class="form-control" name="description" rows="5" required></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-lg-3 col-form-label">Icon URL</label>
											<div class="col-lg-9">
												<input type="text" class="form-control" name="icon" required placeholder="Enter Icon URL">
											</div>
										</div>
									</div>
								</div>
								<div class="text-left">
									<input type="submit" class="btn btn-primary" value="Submit" name="insert" style="margin-left:200px;">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<!----End City add section  --->

			<!----view city  --->
			<div class="row">
				<div class="col-sm-12">
					<div class="card">
						<div class="card-header">
							<h4 class="card-title">City List</h4>

						</div>
						<div class="card-body">

							<table id="basic-datatable" class="table table-bordered table-hover">
								<thead>
									<tr>
										<th>#</th>
										<th>Country</th>
										<th>Category Name</th>
										<th>Description</th>
										<th>Icon</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$query = mysqli_query($con, "SELECT c.id, c.category_name, c.description, c.icon, co.country_name FROM categories c JOIN countries co ON c.country_id = co.id");
									$cnt = 1;
									while ($row = mysqli_fetch_array($query)) {
									?>
										<tr>
											<td><?php echo $cnt; ?></td>
											<td><?php echo $row['country_name']; ?></td>
											<td><?php echo $row['category_name']; ?></td>
											<td><?php echo $row['description']; ?></td>
											<td><?php echo htmlspecialchars($row['icon']); ?></td>
											<td>
												<a href="categoriesedit.php?id=<?php echo $row['id']; ?>"><button class="btn btn-info">Edit</button></a>
												<a href="categoriesdelete.php?id=<?php echo $row['id']; ?>"><button class="btn btn-danger">Delete</button></a>
											</td>
										</tr>
									<?php $cnt++;
									} ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>
			</div>
			<!-- view City -->
		</div>
	</div>
	<!-- /Main Wrapper -->
	<!---
			
			
			
			---->

	<!-- jQuery -->
	<script src="assets/js/jquery-3.2.1.min.js"></script>

	<!-- Bootstrap Core JS -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- Slimscroll JS -->
	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

	<!-- Datatables JS -->
	<!-- Datatables JS -->
	<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
	<script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
	<script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

	<script src="assets/plugins/datatables/dataTables.select.min.js"></script>

	<script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
	<script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
	<script src="assets/plugins/datatables/buttons.html5.min.js"></script>
	<script src="assets/plugins/datatables/buttons.flash.min.js"></script>
	<script src="assets/plugins/datatables/buttons.print.min.js"></script>

	<!-- Custom JS -->
	<script src="assets/js/script.js"></script>

</body>

</html>
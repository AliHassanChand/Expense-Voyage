<?php
session_start();
include("config.php");

if (!isset($_SESSION['auser'])) {
    header("location:index.php");
    exit();
}

// Initialize messages
$error = "";
$msg = "";

// Fetch countries for dropdown
$countries_query = mysqli_query($con, "SELECT id, country_name FROM countries");

// Check if the form is submitted
if (isset($_POST['insert'])) {
    $trip_id = $_GET['id']; // Get trip ID from URL
    $country = $_POST['country'];
    $departure_date = $_POST['departure_date'];
    $departure_city = $_POST['departure_city'];
    $destination = $_POST['destination'];
    $stops = $_POST['stops'];
    $hotels = $_POST['hotels'];
    $transportation_mode = $_POST['transportation_mode'];
    $facilities = $_POST['facilities'];
    $duration_days = $_POST['duration_days'];
    $budget = $_POST['budget'];
    $itinerary = $_POST['itinerary'];
    $destination_img = $_POST['destination_img'];

    // Validate required fields
    if (!empty($country) && !empty($departure_date) && !empty($departure_city) && !empty($destination) && !empty($duration_days) && !empty($budget)) {
        $sql = "UPDATE combine_trips 
                SET country = '{$country}', 
                    departure_date = '{$departure_date}', 
                    departure_city = '{$departure_city}', 
                    destination = '{$destination}', 
                    stops = '{$stops}', 
                    hotels = '{$hotels}', 
                    transportation_mode = '{$transportation_mode}', 
                    facilities = '{$facilities}', 
                    duration_days = '{$duration_days}', 
                    budget = '{$budget}', 
                    itinerary = '{$itinerary}', 
                    destination_img = '{$destination_img}' 
                WHERE id = {$trip_id}";

        $result = mysqli_query($con, $sql);
        if ($result) {
            $msg = "<p class='alert alert-success'>Trip Updated Successfully</p>";
            header("Location: combineTrips.php?msg=$msg");
            exit();
        } else {
            $error = "<p class='alert alert-warning'>* Trip Not Updated</p>";
        }
    } else {
        $error = "<p class='alert alert-warning'>* Fill all the Required Fields</p>";
    }
}

// Fetch trip details
$trip_id = $_GET['id'];
$sql = "SELECT * FROM combine_trips WHERE id = {$trip_id}";
$result = mysqli_query($con, $sql);

// Check for errors
if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

// Check if any trip was found
if (mysqli_num_rows($result) == 0) {
    echo "<p class='alert alert-warning'>No trip found with this ID.</p>";
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">


<head>
	<title>Expense Voyage - Combine Trips Edit</title>
</head>
<?php include 'head.php'; ?>

<body>

	<!-- Main Wrapper -->


	<!-- Header -->
	<?php include("header.php"); ?>
	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col">
						<h3 class="page-title">State</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
							<li class="breadcrumb-item active">State</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /Page Header -->

			<!-- city add section -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<h1 class="card-title">Add City</h1>

							<?php
							// Start output
							while ($row = mysqli_fetch_assoc($result)) {
							?>

								<div>
									<?php echo $error; ?>
									<?php echo $msg; ?>
									<?php if (isset($_GET['msg'])) echo $_GET['msg']; ?>
								</div>

								<form method="post">
									<div class="card-body">
										<div class="row">
											<div class="col-xl-6">
												<h5 class="card-title">Trip Details</h5>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Country</label>
													<div class="col-lg-9">
														<select class="form-control" name="country" required>
															<option value="">Select Country</option>
															<?php
															// Fetch countries for dropdown
															while ($country_row = mysqli_fetch_assoc($countries_query)) {
																$selected = ($country_row['country_name'] == $row['country']) ? 'selected' : '';
																echo "<option value='{$country_row['country_name']}' {$selected}>" . htmlspecialchars($country_row['country_name']) . "</option>";
															}
															?>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Departure Date</label>
													<div class="col-lg-9">
														<input type="date" class="form-control" name="departure_date" value="<?php echo htmlspecialchars($row['departure_date']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Departure City</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="departure_city" value="<?php echo htmlspecialchars($row['departure_city']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Destination</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="destination" value="<?php echo htmlspecialchars($row['destination']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Stops</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="stops" rows="3"><?php echo htmlspecialchars($row['stops']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Hotels</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="hotels" rows="3"><?php echo htmlspecialchars($row['hotels']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Transportation Mode</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="transportation_mode" value="<?php echo htmlspecialchars($row['transportation_mode']); ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Facilities</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="facilities" rows="3"><?php echo htmlspecialchars($row['facilities']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Duration (Days)</label>
													<div class="col-lg-9">
														<input type="number" class="form-control" name="duration_days" value="<?php echo htmlspecialchars($row['duration_days']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Budget</label>
													<div class="col-lg-9">
														<input type="number" class="form-control" name="budget" step="0.01" value="<?php echo htmlspecialchars($row['budget']); ?>" required>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Itinerary</label>
													<div class="col-lg-9">
														<textarea class="form-control" name="itinerary" rows="5"><?php echo htmlspecialchars($row['itinerary']); ?></textarea>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Destination Image URL</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="destination_img" value="<?php echo htmlspecialchars($row['destination_img']); ?>" placeholder="Enter Destination Image URL">
													</div>
												</div>
											</div>
										</div>
										<div class="text-left">
											<input type="submit" class="btn btn-primary" value="Update Trip" name="insert" style="margin-left:200px;">
										</div>
									</div>
								</form>

							<?php
							}
							?>
						</div>
					</div>
				</div>
				<!----End City add section  --->

			</div>
		</div>
		<!-- /Main Wrapper -->
		<!---
			
			
			
			---->

		<!-- jQuery -->
		<script src="assets/js/jquery-3.2.1.min.js"></script>

		<!-- Bootstrap Core JS -->
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

		<!-- Datatables JS -->
		<!-- Datatables JS -->
		<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>

		<script src="assets/plugins/datatables/dataTables.select.min.js"></script>

		<script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatables/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatables/buttons.flash.min.js"></script>
		<script src="assets/plugins/datatables/buttons.print.min.js"></script>

		<!-- Custom JS -->
		<script src="assets/js/script.js"></script>

</body>

</html>
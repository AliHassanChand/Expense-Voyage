<?php
session_start();
include("config.php");

if (!isset($_SESSION['auser'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $admin_id = $_GET['id'];

    // Fetch admin details
    $query = "SELECT * FROM admins WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 'i', $admin_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];

            // Prepare the update query
            $update_query = "UPDATE admins SET username=?, email=?";

            // Add password update if provided
            if (!empty($password)) {
                $update_query .= ", password=?";
            }

            $update_query .= " WHERE id=?";
            $params = [$username, $email];

            // Add password to parameters if set
            if (!empty($password)) {
                $params[] = password_hash($password, PASSWORD_DEFAULT);  // Hash the password
            }
            $params[] = $admin_id;

            if ($stmt = mysqli_prepare($con, $update_query)) {
                // Build the parameter type string
                $types = str_repeat('s', count($params) - 1); // 's' for string
                if (!empty($password)) {
                    $types .= 's'; // Add another 's' if password is included
                }
                $types .= 'i'; // Add 'i' for integer admin ID

                mysqli_stmt_bind_param($stmt, $types, ...$params);
                if (mysqli_stmt_execute($stmt)) {
                    header("Location: adminlist.php?msg=Admin details updated successfully");
                    exit();
                } else {
                    echo "Error: " . mysqli_error($con);
                }
            } else {
                die("Statement preparation failed: " . mysqli_error($con));
            }
        }
    } else {
        header("Location: adminlist.php");
        exit();
    }
} else {
    header("Location: adminlist.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Expense Voyage - Admin-Edit</title>
</head>
<?php include 'head.php'; ?>

<body>
    <?php include("header.php"); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="container">
                <h2>Edit Admin</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                        <small class="form-text text-muted">Leave blank if you do not want to change the password.</small>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>